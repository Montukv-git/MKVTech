# MKVTech

Vite + React + Tailwind + Framer Motion portfolio for Montukeshwar Vaishnaw.

## Development
npm install
npm run dev

## Build
npm run build
npm run preview

## Deploy
Push to the `main` branch. GitHub Actions will automatically build and publish to:
https://montukv-git.github.io/MKVTech/
